package com.oneness.fdxmerchant.Models.OrderModels.CreateOrderModels;

public class CustomCartModel {
    public String cart_id = "";
    public String product_id = "";
}
