package com.oneness.fdxmerchant.Models.ItemManagementModels;

public class UpdateResponseModel {
    public boolean error = false;
    public String message = "";
}
