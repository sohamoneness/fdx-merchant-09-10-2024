package com.oneness.fdxmerchant.Models.CartModels;

public class CartClearResponseModel {
    public boolean error = false;
    public String message = "";
}
