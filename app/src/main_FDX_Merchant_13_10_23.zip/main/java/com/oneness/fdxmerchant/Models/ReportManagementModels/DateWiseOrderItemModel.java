package com.oneness.fdxmerchant.Models.ReportManagementModels;

public class DateWiseOrderItemModel {
    public String id = "";
    public String order_id = "";
    public String product_name = "";
    public String product_image = "";
    public String quantity = "";
    public String price = "";
    public String add_on_name = "";
    public String add_on_price = "";
    public String add_on_quantity = "";
    public String add_on_name2 = "";
    public String add_on_price2 = "";
    public String add_on_quantity2 = "";
    public String created_at = "";
    public String updated_at = "";
}
