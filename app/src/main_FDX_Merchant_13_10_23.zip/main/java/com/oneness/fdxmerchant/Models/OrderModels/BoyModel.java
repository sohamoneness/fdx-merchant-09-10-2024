package com.oneness.fdxmerchant.Models.OrderModels;

public class BoyModel {
    public String id = "";
    public String name = "";
    public String mobile = "";
    public String email = "";
    public String password = "";
    public String image = "";
    public String country = "";
    public String city = "";
    public String address = "";
    public String pin = "";
    public String vehicle_type = "";
    public String gender = "";
    public String date_of_birth = "";
    public String status = "";
    public String is_deleted = "";
    public String remember_token = "";
    public String created_at = "";
    public String updated_at = "";
    public String is_available = "";
}
