package com.oneness.fdxmerchant.Models.ItemManagementModels;

public class AddItemResponseModel {
    public boolean error = false;
    public String message = "";
}
