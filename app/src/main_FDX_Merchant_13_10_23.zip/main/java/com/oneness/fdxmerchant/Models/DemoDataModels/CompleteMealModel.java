package com.oneness.fdxmerchant.Models.DemoDataModels;

public class CompleteMealModel {
    public String item = "";
    public String price = "";

}
