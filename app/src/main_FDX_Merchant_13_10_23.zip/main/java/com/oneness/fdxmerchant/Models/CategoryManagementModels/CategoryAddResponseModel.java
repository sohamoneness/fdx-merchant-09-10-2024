package com.oneness.fdxmerchant.Models.CategoryManagementModels;

public class CategoryAddResponseModel {
    public boolean error = false;
    public String message = "";
}
