package com.oneness.fdxmerchant.Models.DemoDataModels;

public class MenuItemModel {
    public String menu_name = "";
    public String menu_details = "";
    public String menu_item_price = "";
}
