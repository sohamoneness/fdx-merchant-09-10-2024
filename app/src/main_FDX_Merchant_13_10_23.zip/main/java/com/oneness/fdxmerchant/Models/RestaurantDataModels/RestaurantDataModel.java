package com.oneness.fdxmerchant.Models.RestaurantDataModels;

public class RestaurantDataModel {

    public String id = "";
    public String name = "";
    public String mobile = "";
    public String email = "";
    public String password = "";
    public String image = "";
    public String description = "";
    public String address = "";
    public String location = "";
    public String lat = "";
    public String lng = "";
    public String start_time = "";
    public String close_time = "";
    public String is_pure_veg = "";
    public String commission_rate = "";
    public String estimated_delivery_time = "";
    public String is_not_taking_orders = "";
    public String status = "";
    public String logo = "";
    public String created_at = "";
    //public String updated_at = "";
    public String including_tax = "";
    public String tax_rate = "";
    public String minimum_order_amount = "";
    public String order_preparation_time = "";
    public String show_out_of_stock_products_in_app = "";

}
