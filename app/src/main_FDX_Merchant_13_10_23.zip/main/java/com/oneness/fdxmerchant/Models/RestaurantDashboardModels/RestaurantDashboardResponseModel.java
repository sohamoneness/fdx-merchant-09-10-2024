package com.oneness.fdxmerchant.Models.RestaurantDashboardModels;

public class RestaurantDashboardResponseModel {
    public boolean error = false;
    public String message = "";
    public DashboardDataModel data;

}
