package com.oneness.fdxmerchant.Models.RestaurantDataModels;

public class RestaurantDataObjectModel {
    public RestaurantDataModel restaurant;
}
