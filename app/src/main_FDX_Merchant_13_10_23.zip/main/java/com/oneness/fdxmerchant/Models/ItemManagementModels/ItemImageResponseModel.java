package com.oneness.fdxmerchant.Models.ItemManagementModels;

public class ItemImageResponseModel {
    public String status = "";
    public String file_link = "";
}
