package com.oneness.fdxmerchant.Models.RestaurantDataModels;

public class ChangePasswordResponseModel {
    public boolean error = false;
    public String message = "";
}
