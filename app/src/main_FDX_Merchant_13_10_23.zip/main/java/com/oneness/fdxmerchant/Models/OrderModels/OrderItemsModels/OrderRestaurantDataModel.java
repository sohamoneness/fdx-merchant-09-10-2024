package com.oneness.fdxmerchant.Models.OrderModels.OrderItemsModels;

import java.util.ArrayList;
import java.util.List;

public class OrderRestaurantDataModel {

    public OrderRestaurantDetailsModel restaurant;
    public List<OrderCategoryModel> categories = new ArrayList<>();

}
