package com.oneness.fdxmerchant.Models.ItemManagementModels;

public class DeleteItemResponseModel {
    public boolean error = false;
    public String message = "";
}
