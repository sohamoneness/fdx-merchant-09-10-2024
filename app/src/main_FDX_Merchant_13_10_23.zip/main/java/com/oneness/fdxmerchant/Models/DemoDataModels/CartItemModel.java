package com.oneness.fdxmerchant.Models.DemoDataModels;

public class CartItemModel {
    public String item_name = "";
    public String extra_item = "";
    public String extra_price = "";
    public String tot_price = "";
    public String qty = "";
    public String type = "";
    public String price = "";
}
