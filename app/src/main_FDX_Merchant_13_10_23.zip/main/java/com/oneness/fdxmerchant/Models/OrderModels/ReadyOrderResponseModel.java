package com.oneness.fdxmerchant.Models.OrderModels;

public class ReadyOrderResponseModel {
    public boolean error = false;
    public String message = "";
}
