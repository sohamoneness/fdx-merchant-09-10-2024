package com.oneness.fdxmerchant.Models.ReportManagementModels;

public class OrderCountDataModel {
    public String month = "";
    public String value = "";
}
