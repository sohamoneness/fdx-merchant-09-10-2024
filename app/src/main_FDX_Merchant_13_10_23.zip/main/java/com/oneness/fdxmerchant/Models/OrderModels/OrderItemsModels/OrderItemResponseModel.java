package com.oneness.fdxmerchant.Models.OrderModels.OrderItemsModels;

public class OrderItemResponseModel {
    public boolean error = false;
    public String message = "";
    public OrderRestaurantDataModel restaurantData;
}
