package com.oneness.fdxmerchant.Models.ProfileModels;

public class DeliveryConfigUpdateResponseModel {
    public boolean error = false;
    public String message = "";
}
