package com.oneness.fdxmerchant.Models.OrderModels;

public class OrderDetailsResponseModel {

    public boolean error = false;
    public String message = "";
    public OrderDetailsModel orderData;

}
