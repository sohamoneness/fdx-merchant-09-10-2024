package com.oneness.fdxmerchant.Models.PlaceOrderModels;

public class PlaceOrderResponseModel {
    public boolean error = false;
    public String message = "";
    public PlacedOrderDetailsModel order;

}
