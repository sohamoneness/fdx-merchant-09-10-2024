package com.oneness.fdxmerchant.Models.ReportManagementModels;

public class PayoutDataModel {
    public String id = "";
    public String restaurant_id = "";
    public String order_ref_id = "";
    public String amount = "";
    public String note = "";
    public String type = "";
    public String created_at = "";
}
