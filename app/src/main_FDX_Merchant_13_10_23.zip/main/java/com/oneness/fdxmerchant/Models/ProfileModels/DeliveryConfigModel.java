package com.oneness.fdxmerchant.Models.ProfileModels;

public class DeliveryConfigModel {
    public String id = "";
    public String restaurant_id = "";
    public String delivery_type = "";
    public String created_at = "";
    public String updated_at = "";
}
