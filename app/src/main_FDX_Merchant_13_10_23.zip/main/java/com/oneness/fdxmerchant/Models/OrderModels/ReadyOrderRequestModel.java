package com.oneness.fdxmerchant.Models.OrderModels;

public class ReadyOrderRequestModel {
    public String id = "";

    public ReadyOrderRequestModel(String id) {
        this.id = id;
    }
}
