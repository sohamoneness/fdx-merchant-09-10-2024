package com.oneness.fdxmerchant.Models.OrderModels.OrderItemsModels;

public class OrderItemModel {
    public String id = "";
    public String category_id = "";
    public String restaurant_id = "";
    public String name = "";
    public String description = "";
    public String is_veg = "";
    public String avalability = "";
    public String addon_status = "";
    public String in_stock = "";
    public String status = "";
    public String created_at = "";
    public String updated_at = "";
    public String is_recomend = "";
    public String meal = "";
    public String packing_charge = "";
    public String is_cutlery_required = "";
    public String min_item_for_cutlery = "";
    public String image = "";
    public String price = "";
    public String offer_price = "";
    public String quantity = "";
    public int flag = 0;
    public String cartID = "";
}
