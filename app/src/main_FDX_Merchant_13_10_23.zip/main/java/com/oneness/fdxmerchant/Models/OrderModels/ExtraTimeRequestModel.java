package com.oneness.fdxmerchant.Models.OrderModels;

public class ExtraTimeRequestModel {
    public String id = "";
    public String extra_preparation_time = "";

    public ExtraTimeRequestModel(String id, String extra_preparation_time) {
        this.id = id;
        this.extra_preparation_time = extra_preparation_time;
    }
}
