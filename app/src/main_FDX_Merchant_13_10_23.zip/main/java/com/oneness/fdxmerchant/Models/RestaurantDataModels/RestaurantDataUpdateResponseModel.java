package com.oneness.fdxmerchant.Models.RestaurantDataModels;

public class RestaurantDataUpdateResponseModel {
    public boolean error = false;
    public String message = "";
    public RestaurantDataModel restaurant;
}
