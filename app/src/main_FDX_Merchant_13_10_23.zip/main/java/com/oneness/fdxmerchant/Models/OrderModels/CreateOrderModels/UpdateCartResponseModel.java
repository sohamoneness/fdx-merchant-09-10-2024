package com.oneness.fdxmerchant.Models.OrderModels.CreateOrderModels;

public class UpdateCartResponseModel {
    public boolean error = false;
    public String message = "";
    public CartDetailsModel cart;
}
