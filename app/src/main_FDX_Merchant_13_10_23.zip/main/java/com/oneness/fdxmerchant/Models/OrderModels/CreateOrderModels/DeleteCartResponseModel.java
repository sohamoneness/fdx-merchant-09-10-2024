package com.oneness.fdxmerchant.Models.OrderModels.CreateOrderModels;

public class DeleteCartResponseModel {
    public boolean error = false;
    public String message = "";
}
