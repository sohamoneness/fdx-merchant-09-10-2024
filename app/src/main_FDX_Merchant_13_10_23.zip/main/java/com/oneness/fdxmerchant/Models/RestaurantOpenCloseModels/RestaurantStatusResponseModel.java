package com.oneness.fdxmerchant.Models.RestaurantOpenCloseModels;

public class RestaurantStatusResponseModel {
    public boolean error = false;
    public String message = "";
}
