package com.oneness.fdxmerchant.Models.ProfileModels;

public class TimingsModel {
    public String id = "";
    public String resturant_id = "";
    public String start_time = "";
    public String end_time = "";
    public String day = "";
}
