package com.oneness.fdxmerchant.Models.NotificationModels;

public class NotificationModel {
    public String id = "";
    public String user_id = "";
    public String restaurant_id = "";
    public String title = "";
    public String image = "";
    public String description = "";
    public String type = "";
    public String created_at = "";
    public String updated_at = "";
}
