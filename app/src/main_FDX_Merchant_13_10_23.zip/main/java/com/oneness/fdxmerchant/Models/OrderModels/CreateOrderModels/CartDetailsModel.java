package com.oneness.fdxmerchant.Models.OrderModels.CreateOrderModels;

public class CartDetailsModel {
    public String id = "";
}
