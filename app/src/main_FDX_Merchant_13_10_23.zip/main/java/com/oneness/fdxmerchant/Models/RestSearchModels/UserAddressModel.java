package com.oneness.fdxmerchant.Models.RestSearchModels;

public class UserAddressModel {
    public String id = "";
    public String user_id = "";
    public String address = "";
    public String location = "";
    public String lat = "";
    public String lng = "";
    public String country = "";
    public String state = "";
    public String city = "";
    public String pin = "";
    public String tag = "";
    public String created_at = "";
    public String updated_at = "";
    public int flag = 0;
}
