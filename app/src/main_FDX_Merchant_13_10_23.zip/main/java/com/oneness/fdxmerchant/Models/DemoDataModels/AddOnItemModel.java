package com.oneness.fdxmerchant.Models.DemoDataModels;

public class AddOnItemModel {
    public String type = "";
    public String id = "";
    public String add_on_item = "";
    public String add_on_price = "";
    public int add_on_tag = 0;

}
