package com.oneness.fdxmerchant.Models.ItemManagementModels;

public class ItemStatusUpdateResponseModel {
    public boolean error = false;
    public String message = "";
}
