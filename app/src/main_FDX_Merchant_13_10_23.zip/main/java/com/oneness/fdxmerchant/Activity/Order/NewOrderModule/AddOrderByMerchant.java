package com.oneness.fdxmerchant.Activity.Order.NewOrderModule;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.oneness.fdxmerchant.R;

public class AddOrderByMerchant extends AppCompatActivity {
    EditText etName, etContact, etAdr, etAmount;
    RadioGroup rgPay;
    RadioButton rbCod, rbOnline;
    Button btnCreate;
    RadioButton rb;
    String payType = "";
    String lat = "", lng = "", pin = "", city = "";
    ImageView ivBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_order_by_merchant);

        etName = findViewById(R.id.etName);
        etContact = findViewById(R.id.etContact);
        etAdr = findViewById(R.id.etAdr);
        etAmount = findViewById(R.id.etAmount);
        rgPay = findViewById(R.id.rgPay);
        rbCod = findViewById(R.id.rbCod);
        rbOnline = findViewById(R.id.rbOnline);
        btnCreate = findViewById(R.id.btnCreate);
        ivBack = findViewById(R.id.ivBack);

        Toast.makeText(this, getIntent().getStringExtra("SELECT_ADDRESS"), Toast.LENGTH_SHORT).show();
        lat = getIntent().getStringExtra("ADR_LAT");
        lng = getIntent().getStringExtra("ADR_LON");

        etAdr.setText(getIntent().getStringExtra("SELECT_ADDRESS"));

        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isBlankValidate()){
                    createOrder(etName.getText().toString(), etContact.getText().toString(),
                            etAdr.getText().toString(), etAmount.getText().toString(), payType);
                }
            }
        });

        rgPay.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                rb = group.findViewById(checkedId);
                payType = rb.getText().toString();
                Toast.makeText(AddOrderByMerchant.this, payType, Toast.LENGTH_SHORT).show();
            }
        });

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    private void createOrder(String name, String contact, String adr, String amount, String payType) {
        Toast.makeText(this, "NEED TO CALL API HERE TO PLACE THE ORDER!!!", Toast.LENGTH_SHORT).show();
        finish();
    }

    private boolean isBlankValidate() {
        if (etName.getText().toString().equals("")){
            Toast.makeText(this, "Please enter customer name!", Toast.LENGTH_SHORT).show();
            return false;
        }else if (etContact.getText().toString().equals("")){
            Toast.makeText(this, "Please enter customer contact!", Toast.LENGTH_SHORT).show();
            return false;
        }else if (etAdr.getText().toString().equals("")){
            Toast.makeText(this, "Please enter customer address!", Toast.LENGTH_SHORT).show();
            return false;
        }else if (etAmount.getText().toString().equals("")){
            Toast.makeText(this, "Please enter order amount!", Toast.LENGTH_SHORT).show();
            return false;
        }else {
            return true;
        }

    }
}