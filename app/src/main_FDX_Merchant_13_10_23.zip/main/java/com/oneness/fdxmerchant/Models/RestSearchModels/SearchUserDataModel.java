package com.oneness.fdxmerchant.Models.RestSearchModels;

public class SearchUserDataModel {

    public String id = "";
    public String name = "";
    public String mobile = "";
    public String email = "";
    public String otp = "";
    public String country = "";
    public String city = "";
    public String address = "";
    public String gender = "";
    public String device_id = "";
    public String device_token = "";
    public String date_of_birth = "";
    public String is_verified = "";
    public String status = "";
    public String is_deleted = "";
    public String created_at = "";
    public String updated_at = "";
}
