package com.oneness.fdxmerchant.Models.ProfileModels;

public class SettingsUpdateResponseModel {
    public boolean error = false;
    public String message = "";
}
