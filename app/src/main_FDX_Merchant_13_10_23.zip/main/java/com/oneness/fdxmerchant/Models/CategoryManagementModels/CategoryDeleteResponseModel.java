package com.oneness.fdxmerchant.Models.CategoryManagementModels;

public class CategoryDeleteResponseModel {
    public boolean error = false;
    public String message = "";
}
