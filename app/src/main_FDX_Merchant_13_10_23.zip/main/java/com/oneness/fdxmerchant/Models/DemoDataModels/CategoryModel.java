package com.oneness.fdxmerchant.Models.DemoDataModels;

public class CategoryModel {
    public String catName = "";
}
