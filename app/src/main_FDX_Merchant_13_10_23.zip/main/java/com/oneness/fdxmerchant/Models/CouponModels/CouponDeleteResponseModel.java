package com.oneness.fdxmerchant.Models.CouponModels;

public class CouponDeleteResponseModel {
    public boolean error = false;
    public String message = "";
}
