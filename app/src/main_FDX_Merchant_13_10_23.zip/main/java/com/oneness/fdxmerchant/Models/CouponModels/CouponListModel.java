package com.oneness.fdxmerchant.Models.CouponModels;

public class CouponListModel {
    public String id = "";
    public String restaurant_id = "";
    public String title = "";
    public String description = "";
    public String code = "";
    public String type = "";
    public String rate = "";
    public String maximum_offer_rate = "";
    public String start_date = "";
    public String end_date = "";
    public String maximum_time_of_use = "";
    public String maximum_time_user_can_use = "";
    public String status = "";
    public String created_at = "";
    public String updated_at = "";
}
