package com.oneness.fdxmerchant.Models.RestSearchModels;

public class SearchRequestModel {
    public String mobile = "";

    public SearchRequestModel(String mobile) {
        this.mobile = mobile;
    }
}
