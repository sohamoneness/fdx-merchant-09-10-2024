package com.oneness.fdxmerchant.Models.CouponModels;

public class UpdateCouponResponseModel {
    public boolean error = false;
    public String message = "";
}
