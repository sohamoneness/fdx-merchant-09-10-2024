package com.oneness.fdxmerchant.Models.RestaurantDataModels;

public class RestaurantDataResponseModel {
    public boolean error = false;
    public String message = "";
    public RestaurantDataObjectModel restaurantData;
}
