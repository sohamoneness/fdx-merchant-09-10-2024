package com.oneness.fdxmerchant.Models.ProfileModels;

public class DayModel {
    public String name = "";
    public String startTime = "";
    public String offTime = "";
    public int tag = 0;
}
