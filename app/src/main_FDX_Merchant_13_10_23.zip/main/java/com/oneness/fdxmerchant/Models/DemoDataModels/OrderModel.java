package com.oneness.fdxmerchant.Models.DemoDataModels;

public class OrderModel {
    public String id = "";
    public String cust_name = "";
    public String ord_status = "";
    public String time = "";
}
