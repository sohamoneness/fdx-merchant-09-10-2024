package com.oneness.fdxmerchant.Models.CategoryManagementModels;

public class CategoryUpdateResponseModel {
    public boolean error = false;
    public String message = "";
}
