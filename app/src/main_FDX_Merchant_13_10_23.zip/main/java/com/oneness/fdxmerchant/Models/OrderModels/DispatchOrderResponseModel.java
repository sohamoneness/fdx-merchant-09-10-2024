package com.oneness.fdxmerchant.Models.OrderModels;

public class DispatchOrderResponseModel {
    public boolean error = false;
    public String message = "";
}
