package com.oneness.fdxmerchant.Models.CartModels;

public class CartDataModel {
    public String id = "";
    public String user_id = "";
    public String device_id = "";
    public String restaurant_id = "";
    public String product_id = "";
    public String product_name = "";
    public String product_description = "";
    public String product_image = "";
    public String price = "";
    public String quantity = "";
    public String is_cutlery_required = "";
    public String cutlery_quantity = "";
    public String created_at = "";
    public String updated_at = "";
}
